<?php
	$signos = [];
	$signos[] =	'Áries';
	$signos[] =	'Touro';
	$signos[] =	'Gêmeos';
	$signos[] =	'Câncer';
	$signos[] =	'Leão';
	$signos[] =	'Virgem';
	$signos[] =	'Libra';
	$signos[] =	'Escorpião';
	$signos[] =	'Sagitário';
	$signos[] =	'Capricórnio';
	$signos[] =	'Aquário';
	$signos[] =	'Peixes';
?>