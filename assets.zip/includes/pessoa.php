<?php
	$pessoa = [
		"id" => 1,
		"nome" => "Leonardo Moura",
		"idade" => 43,
		"idSigno" => 8,
		"masculino" => true,
		"descricao" => "Uma pessoa muito regrada, centrada. Defende a moral e os bons costumes sempre que pode.",
		"sonho" => "Pular de parapente do alto do himalaia",
		"amiga" => true
	];
?>